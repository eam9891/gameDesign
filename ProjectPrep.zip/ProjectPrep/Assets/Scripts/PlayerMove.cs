﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {
	public float speed;
	public GameObject board1, board2, board3, board4, gate1, key1;
	public Material dead;
	private bool alive = true, hasItem, hasKey1 = false;
	private GameObject theChild;

	// Use this for initialization
	void Start () {
		board2.SetActive(false);
        board3.SetActive(false);
        board4.SetActive(false);
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (alive) {
			float moveH = Input.GetAxis ("Horizontal");
			float moveV = Input.GetAxis ("Vertical");

			Vector3 movement = new Vector3 (transform.position.x + moveH / speed, transform.position.y, 
				                  transform.position.z + moveV / speed);
			transform.position = movement;
			if(Input.GetKeyDown(KeyCode.Space) && hasItem){
				theChild.transform.parent = null;
				hasItem = false;
			}
		}
	}

	void OnTriggerEnter (Collider hitThis)
	{
		if (alive) {
			Vector3 offset;

			if (hitThis.CompareTag("1to2")) {
				board1.SetActive(false);
				board2.SetActive(true);
				GameObject.Find("Main Camera").transform.Translate (0f, 0f, 20f, Space.World);

			} else if (hitThis.CompareTag ("2to1")) {
				board2.SetActive(false);
				board1.SetActive(true);
				GameObject.Find("Main Camera").transform.Translate (0f, 0f, -20f, Space.World);

			} else if (hitThis.CompareTag("2to3")) {
                board2.SetActive(false);
                board3.SetActive(true);
                GameObject.Find("Main Camera").transform.Translate(-20f, 0f, 0f, Space.World);

            } else if (hitThis.CompareTag("3to2")) {
                board3.SetActive(false);
                board2.SetActive(true);
                GameObject.Find("Main Camera").transform.Translate(20f, 0f, 0f, Space.World);

            } else if (hitThis.CompareTag("Gate1") && hasKey1 ) {
                gate1.SetActive(false);
                board1.SetActive(false);
                board4.SetActive(true);
                GameObject.Find("Main Camera").transform.Translate(20f, 0f, 0f, Space.World);

            }
            else if (hitThis.CompareTag("4to1"))
            {
                board1.SetActive(true);
                board4.SetActive(false);
                GameObject.Find("Main Camera").transform.Translate(-20f, 0f, 0f, Space.World);

            }



            else if (hitThis.CompareTag ("Enemy")) {
				alive = false;
				GetComponent<Renderer> ().material = dead;
			} else if (hitThis.CompareTag ("Item") && !hasItem) {
				offset = hitThis.transform.position - transform.position;
				hitThis.transform.position = transform.position + offset * 2;
				hitThis.transform.parent = this.transform;
				hasItem = true;
				theChild = hitThis.gameObject;
                
			} else if (hitThis.CompareTag("Key1") && !hasItem) {
                offset = hitThis.transform.position - transform.position;
                hitThis.transform.position = transform.position + offset * 2;
                hitThis.transform.parent = this.transform;
                hasItem = true;
                hasKey1 = true;
                theChild = hitThis.gameObject;

            }
        }
	}
}
